
﻿ATENÇÃO!

O conteúdo está disponível para visualização no YouTube por exceder o limite máximo permitido pelo GitHub. 
Acesse o link abaixo para assistir o vídeo do conteúdo em vídeo “Instalando Python”

Link: https://youtu.be/vxzpzd0OQ6E
