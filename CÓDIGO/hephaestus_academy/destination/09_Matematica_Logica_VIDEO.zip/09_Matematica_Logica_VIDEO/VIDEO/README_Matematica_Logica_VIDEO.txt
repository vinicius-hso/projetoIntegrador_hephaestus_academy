ATENÇÃO!

O conteúdo está disponível para visualização no YouTube por exceder o limite máximo permitido pelo GitHub. 
Acesse o link abaixo para assistir o vídeo do conteúdo em vídeo “Introdução à Lógica - Matemática Discreta”

Link: https://youtu.be/3bKErh1nQyo

Hephaestus Academy